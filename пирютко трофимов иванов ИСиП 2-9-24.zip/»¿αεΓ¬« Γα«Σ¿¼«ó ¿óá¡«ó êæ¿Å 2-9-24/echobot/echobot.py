import telebot

API_TOKEN = "8178068862:AAGmOx-c3tUqdOOoKAtUaVQC6zRJ7LL7K6Q"
bot = telebot.TeleBot("8178068862:AAGmOx-c3tUqdOOoKAtUaVQC6zRJ7LL7K6Q")

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Всем SKIBIDI xD, пишите свои соо")

@bot.message_handler(commands=['info'])
def send_welcome(message):
    bot.reply_to(message, "information(Информация)")

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    if message.text == "привет":
        bot.reply_to(message, "чувак")
    else:
        bot.reply_to(message, message.text)
bot.infinity_polling()
