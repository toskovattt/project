import pandas
import telebot
import random
from telebot import types
API_TOKEN = "7944873521:AAE0gyJhUzrte2RRMycNUT0ndT0q8khpkNw"
bot = telebot.TeleBot("7944873521:AAE0gyJhUzrte2RRMycNUT0ndT0q8khpkNw")
u_w = 0
b_w = 0
def create():
    markup = types.InlineKeyboardMarkup()
    markup.row(
        types.InlineKeyboardButton("Камень", callback_data='Камень'),
        types.InlineKeyboardButton("Ножницы", callback_data='Ножницы'),
        types.InlineKeyboardButton("Бумага", callback_data='Бумага')
    )
    return markup
@bot.message_handler(commands=['start'])
def send_welcome(message):
    global u_w, b_w
    u_w = 0
    b_w = 0
    bot.send_message(
        message.chat.id,
        "Играем до 3  щ: 0-0\n"
        "ход:",
        reply_markup=create()
    )
@bot.message_handler(commands=['help'])
def send_help(message):
    help_text = (
        "помощь ты нажал нажал ты помощь"
    )
    bot.send_message(message.chat.id, help_text)
@bot.callback_query_handler(func=lambda call: call.data in ['Камень', 'Ножницы', 'Бумага'])
def handle_callback(call):
    global u_w, b_w
    user_choice = call.data
    bot_choice = random.choice(['Камень', 'Ножницы', 'Бумага'])
    if user_choice == bot_choice:
        result = "Ничья!"
    elif (user_choice == 'Камень' and bot_choice == 'Ножницы') or \
            (user_choice == 'Ножницы' and bot_choice == 'Бумага') or \
            (user_choice == 'Бумага' and bot_choice == 'Камень'):
        result = "Вы выиграли раунд!"
        u_w += 1
    else:
        result = "Бот выиграл раунд!"
        b_w += 1
    message_text = (
        f"Вы выбрали: {user_choice}\n"
        f"Бот выбрал: {bot_choice}\n"
        f"{result}\n\n"
        f"Счет: Вы {u_w} - {b_w} Бот"
    )
    if u_w >= 3 or b_w >= 3:
        winner = "Вы победили в игре!" if u_w >= 3 else "Бот победил в игру!"
        message_text += f"\n\n{winner}\nНажмите /start для новой игры."

        bot.edit_message_text(
            message_text,
            call.message.chat.id,
            call.message.message_id
        )
        return
    bot.edit_message_text(
        message_text,
        call.message.chat.id,
        call.message.message_id,
        reply_markup=create()
    )

    @bot.message_handler(func=lambda message: True)
    def echo_all(message):
        if message.text:
            bot.reply_to(message, "некорректный ввод")


@bot.message_handler(commands=['info'])
def send_welcome(message):
    bot.reply_to(message, "information(Информация)")

df = pandas.read_excel('BD.xlsx')
print(df.head())

bot.infinity_polling()

